-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 24 2022 г., 22:57
-- Версия сервера: 8.0.24
-- Версия PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson-8`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `photo1` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `photo2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `photo3` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `price` int DEFAULT NULL,
  `count` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `photo1`, `photo2`, `photo3`, `title`, `text`, `price`, `count`) VALUES
(148, 'photo1.jpg', 'photo2.jpg', 'photo3.jpg', 'Пуловер мелкой вязки', 'С небольшим воротником-стойкой.', 990, 30),
(149, 'photo4.jpg', 'photo5.jpg', 'photo6.jpg', 'Мужской пуловер в спортивном стиле', 'Спортивный дизайн. Машинная стирка.', 2490, 2),
(152, 'photo7.jpg', 'photo8.jpg', 'photo9.jpg', 'Стильный пуловер с аппликацией', 'С изнаночными швами и шалевым воротником', 2490, 14),
(153, 'photo10.jpg', 'photo11.jpg', 'photo12.jpg', 'Мужской шарф', 'Мужской шарф с бахромой, сдержанная серо-чёрная расцветка.', 990, 0),
(154, 'photo13.jpg', 'photo14.jpg', 'photo15.jpg', 'Классические часы-хронограф', 'Часы-хронограф с кожаным ремешком, серебристыми деталями и тёмным циферблатом.', 3499, 0),
(155, 'photo16.jpg', 'photo17.jpg', 'photo18.jpg', 'Стильные мужские наручные часы-хронограф', 'В трендовом стиле милитари: мужские наручные часы-хронограф на браслете из натуральной кожи. Циферблат выполнен в классическом дизайне в угольно-черной и золотой гамме', 6290, 0),
(156, 'photo19.jpg', 'photo20.jpg', 'photo21.jpg', 'Джинсы стрейч с деталями на карманах', 'Спортивные джинсы стрейч покроя Slim Fit. Карманы украшены красивыми деталями.', 1990, 3),
(157, 'photo22.jpg', 'photo23.jpg', 'photo24.jpg', 'Джинсы стрейч Slim Fit Tapered', 'Выбеленный материал, декоративные складки.', 2090, 0),
(158, 'photo25.jpg', 'photo26.jpg', 'photo27.jpg', 'Джинсы стрейч Regular Fit Straight с потёртостями', 'На молнии.', 2090, 1),
(167, NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `purchases`
--

CREATE TABLE `purchases` (
  `id` int NOT NULL,
  `user` int NOT NULL,
  `goods` int NOT NULL,
  `count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `purchases`
--

INSERT INTO `purchases` (`id`, `user`, `goods`, `count`) VALUES
(3, 7, 148, 2),
(4, 7, 152, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `text`) VALUES
(6, 'ss', 'ddd'),
(7, 'ss', 'ddd'),
(8, 'ss', 'ddd');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `login` varchar(10) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `admin` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'false',
  `session` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login`, `pass`, `admin`, `session`) VALUES
(7, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'true', '1osclq52l0b5v6tdus69risbdme246vf'),
(9, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'false', '0');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT для таблицы `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
